#! /bin/sh

./gradlew clean build jacocoTestReport && ./gradlew assembleRelease