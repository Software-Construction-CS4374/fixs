package cn.hikyson.godeye.monitor.modules.thread;

/**
 * @deprecated use {@link cn.hikyson.godeye.core.internal.modules.thread.ThreadTagger} to {@link cn.hikyson.godeye.core.internal.modules.thread.ThreadConfig#threadTagger}
 */
@Deprecated
public interface ThreadRunningProcessClassifier {
}
