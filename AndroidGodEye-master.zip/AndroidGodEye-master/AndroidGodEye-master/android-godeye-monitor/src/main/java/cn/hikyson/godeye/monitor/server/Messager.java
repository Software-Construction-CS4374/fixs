package cn.hikyson.godeye.monitor.server;

public interface Messager {
    void sendMessage(String message);
}
