package cn.hikyson.android.godeye.xcrash;

import java.util.List;

import cn.hikyson.godeye.core.internal.modules.crash.CrashConfig;
import cn.hikyson.godeye.core.internal.modules.crash.CrashInfo;
import io.reactivex.functions.Consumer;

public class GodEyePluginXCrash {

    public static void init(final CrashConfig crashContext, final Consumer<List<CrashInfo>> consumer) {//FDS fix method arg could be final

    }
}
