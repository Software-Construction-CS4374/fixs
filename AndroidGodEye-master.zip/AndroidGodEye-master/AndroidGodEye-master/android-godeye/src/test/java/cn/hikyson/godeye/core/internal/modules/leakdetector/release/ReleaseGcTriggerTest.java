package cn.hikyson.godeye.core.internal.modules.leakdetector.release;

import android.os.Build;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import cn.hikyson.godeye.core.helper.RoboTestApplication;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = Build.VERSION_CODES.LOLLIPOP, application = RoboTestApplication.class)
public class ReleaseGcTriggerTest {
	ReleaseGcTriggerTest(){}//FDS fix at least one constructor

    @Test
    public void runGc() {
    }
}