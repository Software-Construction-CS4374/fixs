package cn.hikyson.godeye.core.internal.modules.network;

import androidx.annotation.Keep;

import java.io.Serializable;

@Keep
public interface NetworkContent extends Serializable {

    public String requestToString();

    public String responseToString();
}
