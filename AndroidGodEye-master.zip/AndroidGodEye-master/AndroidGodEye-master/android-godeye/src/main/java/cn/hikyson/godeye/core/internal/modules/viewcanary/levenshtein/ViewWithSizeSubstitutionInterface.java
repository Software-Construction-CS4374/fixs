package cn.hikyson.godeye.core.internal.modules.viewcanary.levenshtein;

public interface ViewWithSizeSubstitutionInterface {
    double cost(ViewIdWithSize cost1, ViewIdWithSize cost2);//FDS fix short var
}
