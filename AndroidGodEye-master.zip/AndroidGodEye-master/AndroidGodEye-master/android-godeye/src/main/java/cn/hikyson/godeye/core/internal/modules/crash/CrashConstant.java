package cn.hikyson.godeye.core.internal.modules.crash;

public class CrashConstant {
	CrashConstant(){}//FDS fix at least one constructor

}
