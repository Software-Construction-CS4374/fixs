package cn.hikyson.godeye.core.monitor;

import java.util.List;

public interface AppInfoConext {
    List<AppInfoLabel> getAppInfo();
}
