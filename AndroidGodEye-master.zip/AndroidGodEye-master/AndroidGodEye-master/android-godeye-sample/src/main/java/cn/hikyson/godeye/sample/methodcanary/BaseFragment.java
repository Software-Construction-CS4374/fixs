package cn.hikyson.godeye.sample.methodcanary;

import android.app.Fragment;


public class BaseFragment extends Fragment {
	BaseFragment(){}//FDS fix at least one constructor
    public void test() {

    }
}
