package cn.hikyson.godeye.sample;

/**
 * Created by kysonchao on 2017/11/24.
 */
interface Loggable {
    void log(String msg);
}
