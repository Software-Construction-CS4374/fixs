# Change Log

You can watch releases [on Maven](https://oss.sonatype.org/content/groups/public/com/github/markzhai/).

## Version 1.5 *(2017-02-26)*

Debug mode stop monitor.

## Version 1.4 *(2016-11-02)*

- Bug fix.
- Add onBlock interceptor.

### 1.4.1 (2017-01-19)

- Bug fix

## Version 1.3 *(2016-08-24)*

- Code refactor.
- Support white-list and concern packages.

## Version 1.2 *(2016-03-16)*

- Much faster! It now has almost none side-effect at run-time.

## Version 1.1 *(2016-01-23)*

- Extract blockcanary to three modules.
- Provide default implementation for BlockCanaryContext.

### 1.1.1 *(2016-01-25)*
fix issue #19 and #23

## Version 1.0 *(2016-01-21)*

Initial release.

### 1.0.1
Fix no-op api not align bug.

### 1.0.2
Add notification sound, fix 2.3 crash.
